<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    //

    public function login(Request $request){

        try {

            $email = $request->email;
            $password = $request->password;

            $user = User::where('email', $email)->first();

            if ($user->password  == md5($password)) {

                $data['user_id'] = $user['id'];
                $data['first_name'] = $user['first_name'];
                $data['last_name'] = $user['last_name'];
                $data['email'] = $user['email'];
                $data['token'] = $user->createToken('API TOKEN')->plainTextToken;

                return response([
                    'status' => 201,
                    'message' => 'Welcome',
                    "data" => $data
                ], 200);
            } else {

                return response([
                    'status' => 202,
                    'message' => 'Password wrong'
                ], 200);
            }


            return response([
                'status' => 203,
                'message' => 'Invalid credentials'
            ], 200);

        } catch (\Throwable $th) {
            return response([
                'status' => 401,
                'message' => $th->getMessage()
            ], 401);
        }
    }

    public function register(Request $request){

        try {

            $user = new User();
            $user->first_name = $request->first_name;
            $user->last_name = $request->last_name;
            $user->email = $request->email;
            $user->firm_name = '';
            $user->otp = '';
            $user->role_id = 5;
            $user->profile_image = '';
            $user->manufacturer_category = '';
            $user->type = 0;
            $user->address = '';
            $user->street = '';
            $user->address_country = 0;
            $user->pincode = 0;
            $user->latitude = 0;
            $user->city = 0;
            $user->longitude = 0;
            $user->website = '';
            $user->contact_person = '';
            $user->phone = '';
            $user->referal_code = '';
            $user->total_loyalty_point = 0;
            $user->commission_rate = 0;
            $user->country_id  = '';
            $user->created_date = now();
            $user->last_login = now();
            $user->added_by  = 0;
            $user->wallet_total_amount = 0;
            $user->wallet_used_amount = 0;
            $user->lang = '';
            $user->is_retailer_approved = '';
            $user->mobile_number = $request->mobile_number;
            $user->password = $request->password;
            $user->user_type = '4';
            $user->gstno = $request->gstno;
            $user->panno = $request->panno;
            $user->save();

            $data['user_id'] = $user['id'];
            $data['first_name'] = $user['first_name'];
            $data['last_name'] = $user['last_name'];
            $data['email'] = $user['email'];
            $data['token'] = $user->createToken('API TOKEN')->plainTextToken;

            return response([
                'status' => 200,
                'message' => 'User Register Successfully',
                'data'=>$data
            ], 200);

        } catch (\Throwable $th) {
            return response([
                'status' => 401,
                'message' => $th->getMessage()
            ], 401);
        }
    }
}
