<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class States extends Model
{
    //
    public $timestamps = false;

    protected $table = "fs_state";

}
